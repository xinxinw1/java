/**
 *** Type ***
 * 
 * gcls(a)          gets the class of a
 * acls(a)          gets the class of the elements of the array a
 * type(a)          gets the type of a as a string;
 *                  (a == null)?"null":ctype(gcls(a));
 * ctype(a)         gets the type of Class a as a string;
 *                  could be "arr", "num", "chr", "str",
 *                  "rgx" (regex), "cns" (cons cell),
 *                  "cls" (class), or gcls(a).toString();
 * 
 *** Predicates ***
 * 
 * arrp(a)          is a an array?
 * xarrp(a)         is a an Xarr? (see Xarr.java)
 * strp(a)          is a a String?
 * nump(a)          is a a Number? (see java.lang.Number)
 * intp(a)          is a an int?
 * doubp(a)         is a a double?
 * chrp(a)          is a a char?
 * rgxp(a)          is a a Regex? (see Regex.java)
 * cnsp(a)          is a a Cons? (see Cons.java)
 * atmp(a)          is a not a Cons or an empty list?
 * nilp(a)          is a an empty list? (see Cons.java)
 * clsp(a)          is a a Class?
 * nullp(a)         is a == null?
 * 
 *** Comparison ***
 * 
 * is(a, b)         is a and b both null or is a.equals(b)?
 * isa(x, a)        is a an instance of Class x or is
 *                  type(a) == String x?
 * in(x, ...a)      is x equal to one of a?
 * 
 *** Display ***
 * 
 * disp(a)          return str that can represent/display a;
 *                  disp(arr(1, 2, 3)) -> "[1, 2, 3]";
 *                  disp("testing") -> "\"testing\"";
 *                  disp('c') -> "'c'";
 *                  disp(lst(1, 2, 3)) -> "(1 2 3)";
 *                  disp(rgx("abc")) -> "/abc/";
 * 
 *** Array ***
 * 
 * arr()            return new Object[0];
 * arr(...a)        creates arrays; call like arr(1, 2, 3)
 * aarr(...a)       creates 2d arrays; call like
 *                  aarr(arr(1, 2), arr(1, 2))
 * array(...a)      creates arrays; items can be of any type; 
 *                  return type is the narrowest class that
 *                  applies to all elements
 * xarr(...a)       creates an Xarr; items can be of any type;
 *                  (see Xarr.java)
 * 
 *** Printing ***
 * 
 * ou(a)            System.out.print(a)
 * out(a)           System.out.println(a)
 * pr(a, ...args)   if a is not a str, ou(disp(a)), else
 *                  replace $1, $2, ..., $n with nth item of args
 *                  and print that (see strf(a, ...args));
 *                  prn("a = $1", arr(1, 2, 3, 4, 5))
 *                  -> out("a = [1, 2, 3, 4, 5]")
 * prn(a, ...args)  same as pr but with newline at end
 * prn()            prints newline
 * 
 *** Input ***
 * 
 * gstr(a)          gets a str from System.in; if a is provided,  
 *                  it is printed before getting input
 * gnum(a)          gets a num from System.in; returns a int or 
 *                  double depending on the input; "3.4" becomes
 *                  double; "45" becomes int
 * gint(a)          gets an int
 * gdoub(a)         gets a doub
 * gchr(a)          gets a char
 * 
 *** Converters ***
 * 
 * tnum(a)          convert a to either int or double
 * tint(a)          convert a to an int
 * tdoub(a)         convert a to a double
 * tstr(a)          convert a to a string
 * tchr(a)          convert a to a char
 * 
 *** Polymorphic ***
 * 
 * len(a)           get length of array or string a
 * get(a, i)        get element or char at index i from
 *                  array or string a
 * set(a, i, x)     set element i to x in array a
 * pos(x, a, n)     a.indexOf(x); get the position of the first 
 *                  element that "is" a or -1 if there are none;
 *                  if a is a string, x can be an array, in which
 *                  case it returns the first pos of any of the
 *                  elements of x; x can also be a regex;
 *                  a can be an array; if n is specified,
 *                  n is the starting pos
 * rpl(x, y, a)     copies a with x replaced with y; if a is
 *                  a string andx is an array, replaces every
 *                  element in x with its corresponding element
 *                  in y; if x is an array but y is not, then
 *                  replaces every element in x with y
 * slice(a, n, m)   a.substring(n, m); gets a slice of a;
 *                  does similar operation on arrays
 * slice(a, n)      slice(a, n, len(a))
 * poses(x, a)      gets all positions of x in a; if x is arr, gets
 *                  all positions of all the elements of x;
 *                  x can be regex as well
 * add(...a)        adds together all elements of a using add2
 * add2(a, b)       if a is a str, makes b a str and adds them;
 *                  if a is an arr, makes new arr with len
 *                  len(a)+len(b) and combines the elements of both *                  arrays; if a is a num, adds the numbers using
 *                  the more general type (int or double)
 * rev(a)           copies a with reversed order
 * grp(a, n)        groups a into groups of n;
 *                  grp("12345", 2) -> ["12", "34", "5"]; 
 *                  grp([1, 2, 3], 2) -> [[1, 2], [3]]
 * rem(x, a)        makes copy of a without x; x can be arr and regex
 * copy(a, c, len)  makes copy of arr a with length len and Class c
 * copy(a, len)     makes copy of arr a with length len
 * copy(a, c)       makes copy of arr a with Class c
 * copy(a)          copy(a, len(a))
 * split(a, x)      splits a by x;
 *                  split("abefeab3", "a") -> ["", "befe", "b3"]
 * nof(a, n)        nof("abc", 3) -> "abcabcabc";
 *                  nof([1, 2], 3) -> [1, 2, 1, 2, 1, 2]
 * has(x, a)        does x exist in a? pos(x, a) != -1; 
 * 
 *** Array ***
 * 
 * narr(type, len)  creates a new standard java array with
 *                  Class type and length len
 * narr(type)       narr(type, 0)
 * push(x, a)       adds x to end of Xarr a
 * pop(a)           removes last element of Xarr a and returns it
 * tail(a, x)       copies array a with len(a)+1 and sets the
 *                  last element to x
 * ntail(a, x)      if a is Xarr, uses push to modify a; otherwise,
 *                  does same as tail(a, x)
 * join(a, x)       joins arr a with str x;
 *                  join(["a", "b", "c"], "-") -> "a-b-c"
 * join(a)          join(a, "")
 * flat(a, x)       applies join logic to arrays;
 *                  flat([[[1]], 5, [3]], 6) -> [[1], 6, 5, 6, 3]
 * flat(a)          flattens arr a one level without adding anything
 *                  flat([[[1]], 5, [3]]) -> [[1], 2, 5, 3]
 *** String ***
 * 
 * str(...a)          joins elements of a into a string;
 *                    str("te", arr(1), 34, 'c') -> "te[1]34ctrue"
 * strf(a, ...args)   string fill; replaces $1, $2, ..., $n in
 *                    str a with nth item in args;
 *                    strf("a = $1, b = $2, c = $3", 1, "t", arr(1))
 *                    -> "a = 1, b = \"t\", c = [1]"
 * astrf(a, args)     same as strf without varargs
 * 
 *** Function ***
 * 
 * fcls(f)            gets the class from function str f;
 *                    fcls("tools.$.prn") -> $.class
 * fname(f)           gets the name of function from str f
 * mthd(c, nm, args)  gets the method in Class c with name nm whose 
 *                    parameters match the arguments args
 * mtchp(m, args)     does the method m match arguments args?
 * apply(f, a)        applies array a to function f;
 *                    apply("tools.$.add", array("e", arr(1, 2), 1))
 *                    -> add("e", arr(1, 2), 1) -> "e[1, 2]1"
 * 
 *** Regex ***
 * 
 * rgx(a)       makes Regex with str a (see Regex.java)
 * 
 *** List ***
 * 
 ** Basic **
 * 
 * nil()        makes an empty list
 * cns(a, b)    makes a cons cell with a and b
 * car(a)       gets the first part of a cons cell
 * cdr(a)       gets the last part of a cons cell
 * nil(a)       empties (makes nil) cons cell a 
 * car(a, x)    sets car(a) to x
 * cdr(a, x)    sets cdr(a) to x
 *
 ** car and cdr extensions **
 *
 * caar(a)      car(car(a))
 * cadr(a)      car(cdr(a))
 * cdar(a)      ...
 * cddr(a)      ...
 * 
 ** General **
 * 
 * lst(...a)    makes a list with a;
 *              lst(1, 2, 3) -> cns(1, cns(2, cns(3, nil())))
 *              -> (1 2 3)
 * 
 *** Error ***
 * 
 * err(nm, a, ...args)  returns an error;
 *                      err("test", "a = $1", arr(1, 2, 3)) ->
 *                      new RuntimeException("Error: test: a =
 *                      [1, 2, 3]");
 * 
 *** Other ***
 * 
 * exit()          System.exit(0); halts the program
 * pause(mil)      loops for mil milliseconds
 * rand(min, max)  generates a random number between min and
 *                 max, inclusive
 *
**/

package tools;

import java.util.Scanner;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.regex.Matcher;
import java.util.Random;

public class $ {
  ////// Type //////
  
  public static Class gcls(Object a){
    return a.getClass();
  }
  
  public static Class acls(Object a){
    if (clsp(a))return ((Class) a).getComponentType();
    return gcls(a).getComponentType();
  }
  
  public static String type(Object a){
    return (a == null)?"null":ctype(gcls(a));
  }
  
  /*public static String atype(Object a){
    return ctype(acls(a));
  }*/
  
  public static String ctype(Class a){
    if (a.isArray() || a == Xarr.class)return "arr";
    if (in(a, int.class, Integer.class, double.class, Double.class))return "num";
    if (in(a, char.class, Character.class))return "chr";
    if (a == String.class)return "str";
    if (a == Regex.class)return "rgx";
    if (a == Cons.class)return "cns";
    if (a == Class.class)return "cls";
    return a.toString();
  }
  
  ////// Predicates //////
  
  public static boolean arrp(Object a){
    return type(a) == "arr";
  }
  
  public static boolean xarrp(Object a){
    return a instanceof Xarr;
  }
  
  public static boolean strp(Object a){
    return a instanceof String;
  }
  
  public static boolean nump(Object a){
    return a instanceof Number;
  }
  
  public static boolean intp(Object a){
    return a instanceof Integer;
  }
  
  public static boolean doubp(Object a){
    return a instanceof Double;
  }
  
  public static boolean chrp(Object a){
    return a instanceof Character;
  }
  
  public static boolean rgxp(Object a){
    return a instanceof Regex;
  }
  
  public static boolean cnsp(Object a){
    return a instanceof Cons;
  }
  
  public static boolean atmp(Object a){
    return !cnsp(a) || ((Cons) a).nilp();
  }
  
  public static boolean nilp(Object a){
    return cnsp(a) && ((Cons) a).nilp();
  }
  
  public static boolean clsp(Object a){
    return a instanceof Class;
  }
  
  public static boolean nullp(Object a){
    return a == null;
  }
  
  ////// Comparison //////
  
  public static boolean is(Object a, Object b){
    return nullp(a)?nullp(b):a.equals(b);
  }
  
  public static boolean isa(Class x, Object a){
    if (a == null)return !x.isPrimitive();
    if (in(x, int.class, Integer.class) && intp(a))return true;
    if (in(x, double.class, Double.class) && doubp(a))return true;
    if (in(x, char.class, Character.class) && chrp(a))return true;
    return x.isInstance(a);
  }
  
  public static boolean isa(String x, Object a){
    return is(type(a), x);
  }
  
  public static boolean in(Object x, Object... a){
    for (int i = 0; i < a.length; i++){
      if (is(a[i], x))return true;
    }
    return false;
  }
  
  ////// Display //////
  
  public static String disp(Object a){
    if (nullp(a))return "null";
    if (arrp(a)){
      String s = "[";
      if (len(a) > 0){
        s += disp(get(a, 0));
        for (int i = 1; i < len(a); i++){
          s += ", " + disp(get(a, i));
        }
      }
      s += "]";
      return s;
    }
    if (chrp(a))return "'" + a + "'";
    if (strp(a))return "\"" + a + "\"";
    if (cnsp(a))return dispCns(a);
    return a.toString();
  }
  
  private static String dispCns(Object a){
    if (nilp(a))return "()";
    if (is(car(a), "qt"))return "'" + disp(cadr(a));
    if (is(car(a), "qq"))return "`" + disp(cadr(a));
    if (is(car(a), "uq"))return "," + disp(cadr(a));
    if (is(car(a), "uqs"))return ",@" + disp(cadr(a));
    if (is(car(a), "neg"))return "~" + disp(cadr(a));
    if (is(car(a), "not"))return "!" + disp(cadr(a));
    return "(" + dispCns2(a) + ")";
  }
  
  private static String dispCns2(Object a){
    if (nilp(cdr(a)))return disp(car(a));
    if (atmp(cdr(a)))return disp(car(a)) + " . " + disp(cdr(a));
    return disp(car(a)) + " " + dispCns2(cdr(a));
  }
  
  ////// Array //////
  
  /*
  if I had
  
  public static int[] arr(int... a){
    return a;
  }
  
  public static int[][] arr(int[]... a){
    return a;
  }
  
  then arr(arr(1, 2, 3)) would return [1, 2, 3]
  because the inner arr is "apply"d to the first method
  */
  
  public static Object[] arr(){
    return new Object[0];
  }
  
  public static int[] arr(int... a){
    return a;
  }
  
  public static double[] arr(double... a){
    return a;
  }
  
  public static char[] arr(char... a){
    return a;
  }
  
  public static String[] arr(String... a){
    return a;
  }
  
  public static int[][] aarr(int[]... a){
    return a;
  }
  
  public static double[][] aarr(double[]... a){
    return a;
  }
  
  public static char[][] aarr(char[]... a){
    return a;
  }
  
  public static String[][] aarr(String[]... a){
    return a;
  }
  
  @SafeVarargs
  public static <T> T[] array(T... a){
    return a;
  }
  
  public static Xarr xarr(Object... a){
    return new Xarr(a);
  }
  
  ////// Printing //////
  
  public static void ou(Object a){
    System.out.print(a);
  }
  
  public static void out(Object a){
    System.out.println(a);
  }
  
  public static void pr(Object a, Object... args){
    if (!strp(a))ou(disp(a));
    else ou(astrf(a, args));
  }
  
  public static void prn(Object a, Object... args){
    if (!strp(a))out(disp(a));
    else out(astrf(a, args));
  }
  
  public static void prn(){
    out("");
  }
  
  ////// Input //////
  
  public static String gstr(){
    Scanner s = new Scanner(System.in);
    return s.nextLine();
  }
  
  public static String gstr(String a){
    ou(a);
    return gstr();
  }
  
  public static Number gnum(){
    return tnum(gstr());
  }
  
  public static Number gnum(String a){
    return tnum(gstr(a));
  }
  
  public static int gint(){
    return tint(gstr());
  }
  
  public static int gint(String a){
    return tint(gstr(a));
  }
  
  public static double gdoub(){
    return tdoub(gstr());
  }
  
  public static double gdoub(String a){
    return tdoub(gstr(a));
  }
  
  public static char gchr(){
    return tchr(gstr());
  }
  
  public static char gchr(String a){
    return tchr(gstr(a));
  }
  
  ////// Converters //////
  
  public static Number tnum(Object a){
    if (nump(a))return (Number) a;
    if (strp(a)){
      if (tdoub(tint(a)) != tdoub(a))return tdoub(a);
      return tint(a);
    }
    if (chrp(a))return tint(a);
    throw err("tnum", "Can't coerce a = $1 to num", a);
  }
  
  public static int tint(Object a){
    if (nump(a))return ((Number) a).intValue();
    if (strp(a)){
      try {
        return Integer.parseInt((String) a);
      } catch (NumberFormatException e){
        return 0;
      }
    }
    if (chrp(a))return (int) (char) a;
    throw err("tint", "Can't coerce a = $1 to int", a);
  }
  
  public static double tdoub(Object a){
    if (nump(a))return ((Number) a).doubleValue();
    if (strp(a)){
      try {
        return Double.parseDouble((String) a);
      } catch (NumberFormatException e){
        return 0;
      }
    }
    if (chrp(a))return (double) (char) a;
    throw err("tdoub", "Can't coerce a = $1 to doub", a);
  }
  
  public static String tstr(Object a){
    return str(a);
  }
  
  public static char tchr(Object a){
    if (chrp(a))return (char) a;
    if (strp(a)){
      if (is(a, ""))return 0;
      return ((String) a).charAt(0);
    }
    if (nump(a))return (char) tint(a);
    throw err("tchr", "Can't coerce a = $1 to chr", a);
  }
  
  ////// Polymorphic //////
  
  public static int len(Object a){
    if (arrp(a)){
      if (xarrp(a))return ((Xarr) a).len();
      return Array.getLength(a);
    }
    if (strp(a))return ((String) a).length();
    throw err("len", "Can't get len of a = $1", a);
  }
  
  public static Object get(Object a, int i){
    if (nullp(a))return null;
    if (arrp(a)){
      if (xarrp(a))return ((Xarr) a).get(i);
      if (i < 0 || i >= len(a))return null;
      return Array.get(a, i);
    }
    if (strp(a)){
      if (i < 0 || i >= len(a))return "";
      return String.valueOf(((String) a).charAt(i));
    }
    throw err("get", "Can't get item i = $1 in a = $2", i, a);
  }
  
  public static Object set(Object a, int i, Object x){
    if (arrp(a)){
      if (xarrp(a))return ((Xarr) a).set(i, x);
      Array.set(a, i, x);
      return x;
    }
    throw err("set", "Can't set item i = $1 in a = $2 to x = $3", i, a, x);
  }
  
  public static int pos(Object x, Object a, int n){
    if (arrp(a)){
      for (int i = n; i < len(a); i++){
        if (is(get(a, i), x))return i;
      }
      return -1;
    }
    if (strp(a)){
      if (strp(x))return ((String) a).indexOf((String) x, n);
      if (rgxp(x)){
        Matcher m = ((Regex) x).mtchr((String) a);
        if (!m.find())return -1;
        return m.start();
      }
      if (arrp(x)){
        int m = -1; int curr;
        for (int i = 0; i < len(x); i++){
          curr = pos(get(x, i), a, n);
          if (curr != -1){
            if (m != -1)m = Math.min(m, curr);
            else m = curr;
          }
        }
        return m;
      }
    }
    throw err("pos", "Can't get pos of x = $1 in a = $2", x, a);
  }
  
  public static int pos(Object x, Object a){
    return pos(x, a, 0);
  }
  
  public static Object rpl(Object x, Object y, Object a){
    if (strp(a)){
      if (strp(x))return ((String) a).replace((String) x, (String) y);
      if (rgxp(x)){
        Matcher m = ((Regex) x).mtchr((String) a);
        return m.replaceAll((String) y);
      }
      if (arrp(x)){
        String s = ""; int i = 0; int k;
        while (i < len(a)){
          for (k = 0; k < len(x); k++){
            if (pos(get(x, k), a, i) == i){
              s += arrp(y)?get(y, k):y;
              i += len(get(x, k));
              break;
            }
          }
          if (k == len(x)){
            s += get(a, i);
            i += 1;
          }
        }
        return s;
      }
    }
    if (arrp(a)){
      Object r;
      if (xarrp(a))r = new Xarr();
      else r = narr(acls(a), len(a));
      if (arrp(x)){
        int k;
        for (int i = 0; i < len(a); i++){
          for (k = 0; k < len(x); k++){
            if (is(get(a, i), get(x, k))){
              set(r, i, arrp(y)?get(y, k):y);
              break;
            }
          }
          if (k == len(x))set(r, i, get(a, i));
        }
      } else {
        for (int i = 0; i < len(a); i++){
          set(r, i, is(get(a, i), x)?y:get(a, i));
        }
      }
      return r;
    }
    throw err("rpl", "Can't rpl x = $1 with y = $2 in a = $3", x, y, a);
  }
  
  public static Object slice(Object a, int n, int m){
    if (n < 0)n = 0;
    if (m < 0)m = 0;
    if (n > len(a))n = len(a);
    if (m > len(a))m = len(a);
    if (n > m)m = n;
    if (strp(a))return ((String) a).substring(n, m);
    if (arrp(a)){
      Object r;
      if (xarrp(a))r = new Xarr();
      else r = narr(acls(a), m-n);
      for (int i = 0; i < m-n; i++){
        set(r, i, get(a, n+i));
      }
      return r;
    }
    throw err("slice", "Can't slice a = $1 from n = $2 to m = $3", a, n, m);
  }
  
  public static Object slice(Object a, int n){
    return slice(a, n, len(a));
  }
  
  public static int[] poses(Object x, Object a){
    if (arrp(a)){
      Object r = new int[0];
      if (arrp(x)){
        for (int i = 0; i < len(a); i++){
          for (int k = 0; k < len(x); k++){
            if (is(get(x, k), get(a, i)))r = tail(r, i);
          }
        }
      } else {
        for (int i = 0; i < len(a); i++){
          if (is(x, get(a, i)))r = tail(r, i);
        }
      }
      return (int[]) r;
    }
    if (strp(a)){
      if (arrp(x)){
        Object r = new int[0]; Object curr; int v;
        for (int i = 0; i < len(a); i++){
          for (int k = 0; k < len(x); k++){
            curr = get(x, k);
            for (v = 0; v < len(curr); v++){
              if (i+v == len(a))break;
              if (!is(get(a, i+v), get(curr, v)))break;
            }
            if (v == len(curr)){
              r = tail(r, i);
              break;
            }
          }
        }
        return (int[]) r;
      }
      if (strp(x)){
        Object r = new int[0]; int v;
        for (int i = 0; i < len(a); i++){
          for (v = 0; v < len(x); v++){
            if (i+v == len(a))break;
            if (!is(get(a, i+v), get(x, v)))break;
          }
          if (v == len(x))r = tail(r, i);
        }
        return (int[]) r;
      }
      if (rgxp(x)){
        Matcher m = ((Regex) x).mtchr((String) a);
        Object r = new int[0];
        while (m.find()){
          r = tail(r, m.start());
        }
        return (int[]) r;
      }
      throw err("poses", "Can't get poses of x = $1 in str a = $2", x, a);
    }
    throw err("poses", "Can't get poses of x = $1 in a = $2", x, a);
  }
  
  public static Object add(Object... a){
    if (len(a) == 0)return 0;
    Object b = a[0];
    for (int i = 1; i < len(a); i++){
      b = add2(b, a[i]);
    }
    return b;
  }
  
  public static Object add2(Object a, Object b){
    if (intp(a)){
      if (intp(b))return (int) a + (int) b;
      if (doubp(b))return tdoub(a) + (double) b;
      if (strp(b)){
        if (doubp(tnum(b)))return tdoub(a) + (double) tnum(b);
        return (int) a + (int) tnum(b);
      }
      throw err("add2", "Can't add int a = $1 to b = $2", a, b);
    }
    if (doubp(a)){
      if (doubp(b))return (double) a + (double) b;
      if (intp(b) || strp(b))return (double) a + tdoub(b);
      throw err("add2", "Can't add doub a = $1 to b = $2", a, b);
    }
    if (arrp(a)){
      if (arrp(b)){
        Object r;
        if (xarrp(a) || xarrp(b) || !is(acls(a), acls(b)))r = new Xarr(a);
        else r = copy(a, len(a)+len(b));
        for (int i = 0; i < len(b); i++){
          set(r, len(a)+i, get(b, i));
        }
        return r;
      }
      return tail(a, b);
    }
    if (strp(a)){
      if (strp(b))return (String) a + (String) b;
      return (String) a + str(b);
    }
    throw err("add2", "Can't add a = $1 to b = $2", a, b);
  }
  
  public static Object rev(Object a){
    if (arrp(a)){
      Object r;
      if (xarrp(a))r = new Xarr();
      else r = narr(acls(a), len(a));
      for (int i = 0; i < len(a); i++){
        set(r, i, get(a, len(a)-1-i));
      }
      return r;
    }
    if (strp(a)){
      String s = "";
      for (int i = len(a)-1; i >= 0; i--){
        s += (String) get(a, i);
      }
      return s;
    }
    throw err("rev", "Can't rev a = $1", a);
  }
  
  public static Object grp(Object a, int n){
    if (n == 0)throw err("grp", "Can't group a = $1 into groups of n = $2", a, n);
    Object r;
    if (xarrp(a))r = new Xarr();
    else r = narr(gcls(a));
    for (int i = 0; i < len(a); i += n){
      r = ntail(r, slice(a, i, i+n));
    }
    return r;
  }
  
  public static Object rem(Object x, Object a){
    if (arrp(a)){
      Object r; 
      if (xarrp(a))r = new Xarr();
      else r = narr(acls(a));
      if (arrp(x)){
        int k;
        for (int i = 0; i < len(a); i++){
          for (k = 0; k < len(x); k++){
            if (is(get(a, i), get(x, k)))break;
          }
          if (k == len(x))r = ntail(r, get(a, i));
        }
      } else {
        for (int i = 0; i < len(a); i++){
          if (!is(get(a, i), x))r = ntail(r, get(a, i));
        }
      }
      return r;
    }
    if (strp(a))return rpl(x, "", a);
    throw err("rem", "Can't rem x = $1 from a = $2", x, a);
  }
  
  public static Object copy(Object a, Class c, int len){
    if (arrp(a)){
      Object r = narr(c, len);
      int end = Math.min(len(a), len);
      for (int i = 0; i < end; i++){
        set(r, i, get(a, i));
      }
      return r;
    }
    return a;
  }
  
  public static Object copy(Object a, int len){
    if (arrp(a)){
      Object r;
      if (xarrp(a))r = new Xarr();
      else r = narr(acls(a), len);
      int end = Math.min(len(a), len);
      for (int i = 0; i < end; i++){
        set(r, i, get(a, i));
      }
      return r;
    }
    return a;
  }
  
  public static Object copy(Object a, Class c){
    return copy(a, c, len(a));
  }
  
  public static Object copy(Object a){
    return copy(a, len(a));
  }
  
  public static Object split(Object a, Object x){
    if (strp(a)){
      if (strp(x)){
        Object r = new String[0];
        int last = 0; int k; int v;
        int i = 0;
        while (i < len(a)){
          for (v = 0; v < len(x); v++){
            if (i+v == len(a))break;
            if (!is(get(a, i+v), get(x, v)))break;
          }
          if (v == len(x)){
            r = tail(r, slice(a, last, i));
            last = i+v;
            i += v;
          } else {
            i++;
          }
        }
        return tail(r, slice(a, last, len(a)));
      }
      if (arrp(x)){
        Object r = new String[0];
        int last = 0; Object curr; int k; int v;
        int i = 0;
        while (i < len(a)){
          for (k = 0; k < len(x); k++){
            curr = get(x, k);
            for (v = 0; v < len(curr); v++){
              if (i+v == len(a))break;
              if (!is(get(a, i+v), get(curr, v)))break;
            }
            if (v == len(curr)){
              r = tail(r, slice(a, last, i));
              last = i+v;
              i += v;
              break;
            }
          }
          if (k == len(x))i++;
        }
        return tail(r, slice(a, last, len(a)));
      }
      if (rgxp(x)){
        Object r = new String[0];
        Matcher m = ((Regex) x).mtchr((String) a);
        int last = 0;
        while (m.find()){
          r = tail(r, slice(a, last, m.start()));
          last = m.end();
        }
        return tail(r, slice(a, last, len(a)));
      }
      throw err("split", "Can't split str a = $1 by x = $2", a, x);
    }
    if (arrp(a)){
      Object r;
      if (xarrp(a))r = new Xarr();
      else r = narr(gcls(a));
      int last = 0;
      if (arrp(x)){
        for (int i = 0; i < len(a); i++){
          for (int k = 0; k < len(x); k++){
            if (is(get(a, i), get(x, k))){
              r = ntail(r, slice(a, last, i));
              last = i+1;
              break;
            }
          }
        }
      } else {
        for (int i = 0; i < len(a); i++){
          if (is(get(a, i), x)){
            r = ntail(r, slice(a, last, i));
            last = i+1;
          }
        }
      }
      return ntail(r, slice(a, last, len(a)));
    }
    throw err("split", "Can't split a = $1 by x = $2", a, x);
  }
  
  public static Object nof(Object a, int n){
    if (strp(a)){
      String s = "";
      for (int i = n; i >= 1; i--)s += (String) a;
      return s;
    }
    if (arrp(a)){
      Object r;
      if (xarrp(a))r = new Xarr();
      else r = narr(acls(a));
      for (int i = n; i >= 1; i--)r = add2(r, a);
      return r;
    }
    throw err("nof", "Can't make n = $1 of a = $2", n, a);
  }
  
  public static boolean has(Object x, Object a){
    if (arrp(x)){
      for (int i = 0; i < len(x); i++){
        if (has1(get(x, i), a))return true;
      }
      return false;
    }
    return has1(x, a);
  }
  
  private static boolean has1(Object x, Object a){
    if (strp(a)){
      if (strp(x))return ((String) a).contains((String) x);
      if (rgxp(x)){
        Matcher m = ((Regex) x).mtchr((String) a);
        return m.find();
      }
      throw err("has1", "Can't find if str a = $1 has x = $2", a, x);
    }
    if (arrp(a)){
      for (int i = 0; i < len(a); i++){
        if (is(get(a, i), x))return true;
      }
      return false;
    }
    throw err("has1", "Can't find if a = $1 has x = $2", a, x);
  }
  
  ////// Array //////
  
  public static Object narr(Class type, int len){
    return Array.newInstance(type, len);
  }
  
  public static Object narr(Class type){
    return narr(type, 0);
  }
  
  public static Object push(Object x, Object a){
    if (xarrp(a))return ((Xarr) a).push(x);
    throw err("push", "Can't push x = $1 onto non-xarr a = $2", x, a);
  }
  
  public static Object pop(Object a){
    if (xarrp(a))return ((Xarr) a).pop();
    throw err("push", "Can't pop from non-xarr a = $2", a);
  }
  
  public static Object tail(Object a, Object x){
    Object r = copy(a, len(a)+1);
    set(r, len(a), x);
    return r;
  }
  
  public static Object ntail(Object a, Object x){
    if (xarrp(a)){
      push(x, a);
      return a;
    }
    return tail(a, x);
  }
  
  public static String join(Object a, String x){
    String s = "";
    if (len(a) > 0){
      s += str(get(a, 0));
      for (int i = 1; i < len(a); i++){
        s += x + str(get(a, i));
      }
    }
    return s;
  }
  
  public static String join(Object a){
    String s = "";
    for (int i = 0; i < len(a); i++){
      if (strp(get(a, i)) || chrp(get(a, i)))s += get(a, i);
      else s += disp(get(a, i));
    }
    return s;
  }
  
  public static Object flat(Object a, Object x){
    Object r = new Xarr();
    if (len(a) > 0){
      r = add2(r, get(a, 0));
      for (int i = 1; i < len(a); i++){
        r = add(r, x, get(a, i));
      }
    }
    return r;
  }
  
  public static Object flat(Object a){
    Object r = new Xarr();
    for (int i = 1; i < len(a); i++){
      r = add2(r, get(a, i));
    }
    return r;
  }
  
  /* would be great to have a lowest common superclass fn
  that does the same as acls(apply("tools.$.array", <arr of objects>))
  maybe http://stackoverflow.com/questions/9797212/finding-the-nearest-common-superclass-or-superinterface-of-a-collection-of-cla
  */
  
  ////// String //////
  
  public static String str(Object... a){
    return join(a);
  }
  
  public static String strf(Object a, Object... args){
    return astrf(a, args);
  }
  
  public static String astrf(Object a, Object args){
    if (strp(a)){
      String[] x = new String[len(args)];
      String[] y = new String[len(args)];
      for (int i = 0; i < len(args); i++){
        x[i] = "$" + (i+1);
        y[i] = disp(get(args, i));
      }
      return (String) rpl(x, y, a);
    }
    throw err("astrf", "First arg a = $1 not a string", a);
  }
  
  ////// Function //////
  
  public static Class fcls(String f){
    int n = f.lastIndexOf(".");
    String cls = (String) slice(f, 0, n);
    
    try {
      return Class.forName(cls);
    } catch (Exception e){
      throw err("fcls", "Class cls = $1 not found", cls);
    }
  }
  
  public static String fname(String f){
    int n = f.lastIndexOf(".");
    return (String) slice(f, n+1);
  }
  
  public static Method mthd(Class c, String nm, Object args){
    Method[] mthds = c.getDeclaredMethods();
    for (int i = 0; i < len(mthds); i++){
      if (is(mthds[i].getName(), nm) && mtchp(mthds[i], args)){
        return mthds[i];
      }
    }
    throw err("mthd", "No matching method found for c = $1, nm = $2, args = $3", c, nm, args);
  }
  
  public static boolean mtchp(Method m, Object args){
    Class[] tps = m.getParameterTypes();
    for (int i = 0; i < len(args); i++){
      if (i == len(tps)-1 && m.isVarArgs()){
        Class va = acls(tps[len(tps)-1]);
        for (int k = i; k < len(args); k++){
          if (!isa(va, get(args, k)))return false;
        }
        return true;
      }
      if (i >= len(tps))return false;
      if (!isa(tps[i], get(args, i)))return false;
    }
    return true;
  }
  
  public static Object[] mtch(Method m, Object args){
    Class[] tps = m.getParameterTypes();
    Object[] arr = new Object[len(tps)];
    for (int i = 0; i < len(args); i++){
      if (i == len(tps)-1 && m.isVarArgs()){
        arr[i] = copy(slice(args, i), acls(tps[len(tps)-1]));
        break;
      }
      arr[i] = get(args, i);
    }
    return arr;
  }
  
  public static Object apply(String f, Object a){
    Class c = fcls(f);
    String nm = fname(f);
    Method m = mthd(c, nm, a);
    Object[] args = mtch(m, a);
    try {
      return m.invoke(null, args);
    } catch (InvocationTargetException e){
      throw (RuntimeException) e.getTargetException();
    } catch (Exception e){
      throw err("apply", "Cannot apply f = $1 to a = $2 due to e = $3", f, a, e);
    }
  }
  
  ////// Regex //////
  
  public static Regex rgx(String a){
    return new Regex(a);
  }
  
  ////// List //////
  
  //// Basic ////
  
  public static Cons nil(){
    return new Cons();
  }
  
  public static Cons cns(Object a, Object b){
    return new Cons(a, b);
  }
  
  public static Object car(Object a){
    return ((Cons) a).car();
  }
  
  public static Object cdr(Object a){
    return ((Cons) a).cdr();
  }
  
  public static Cons nil(Object a){
    return ((Cons) a).nil();
  }
  
  public static Object car(Object a, Object x){
    return ((Cons) a).car(x);
  }
  
  public static Object cdr(Object a, Object x){
    return ((Cons) a).cdr(x);
  }
  
  //// car and cdr extensions ////
  
  public static Object caar(Object a){
    return car(car(a));
  }
  
  public static Object cadr(Object a){
    return car(cdr(a));
  }
  
  public static Object cdar(Object a){
    return cdr(car(a));
  }
  
  public static Object cddr(Object a){
    return cdr(cdr(a));
  }
  
  //// General ////
  
  public static Cons lst(Object... a){
    Cons r = nil();
    for (int i = len(a)-1; i >= 0; i--){
      r = cns(a[i], r);
    }
    return r;
  }
  
  ////// Error //////
  
  public static RuntimeException err(String nm, String a, Object... args){
    return new RuntimeException("Error: " + nm + ": " + astrf(a, args));
  }
  
  ////// Other //////
  
  public static void exit(){
    System.exit(0);
  }
  
  public static void pause(int mil){
    try {
      Thread.sleep(mil);
    } catch (InterruptedException e){}
  }
  
  public static int rand(int min, int max){
    Random r = new Random();
    return r.nextInt(max-min+1)+min;
  }
}
