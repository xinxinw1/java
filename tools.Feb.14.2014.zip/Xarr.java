/**
 * Xarr is an extended version of Java arrays that can hold items
 * of any type. Similar to ArrayList, it makes itself larger as 
 * needed. Xarr's are not meant to be created directly, but instead
 * through an already made Java array
 * 
 * Usage:
 * Xarr a = new Xarr();
 * $.prn(a.push(1)) -> [1]
 * $.prn(a.push("str")) -> [1, "str"]
 * $.prn(a.push($.arr(1, 2, 3))) -> [1, "str", [1, 2, 3]]
 * $.prn(a.get(1)) -> "str"
 * $.prn(a.set(0, 'c')) -> 'c'
 * $.prn(a) -> ['c', "str", [1, 2, 3]]
 * $.prn(a.pop()) -> [1, 2, 3]
 * $.prn(a) -> ['c', "str"]
 * $.prn(a.ushf(4.3)) -> [4.3, 'c', "str"]
 * $.prn(a.rem(1)) -> 'c'
 * $.prn(a) -> [4.2, "str"]
 * 
 * $.prn(a = $.xarr(1, "str", $.xarr(2))) -> [1, "str", [2]]
 * $.prn($.push(5, a)) -> [1, "str", [2], 5]
 * $.prn($.get(a, 2)) -> [2]
 * $.prn($.set(a, 0, 3.4)) -> [3.4, "str", [2], 5]
 * $.prn($.pop(a)) -> 5
 * $.prn(a) -> [3.4, "str", [2]]
 *
**/

package tools;

import java.lang.reflect.Array;

public class Xarr {
  private Object[] arr;
  private int len;
  
  public Xarr(){
    arr = new Object[0];
    len = 0;
  }
  
  public Xarr(Object a){
    arr = new Object[0];
    len = 0;
    if (a instanceof Xarr){
      Xarr r = (Xarr) a;
      for (int i = 0; i < r.len(); i++){
        set(i, r.get(i));
      }
    } else {
      for (int i = 0; i < Array.getLength(a); i++){
        set(i, Array.get(a, i));
      }
    }
  }
  
  public Object get(int n){
    if (n >= len || n < 0)return null;
    return arr[n];
  }
  
  public Object set(int n, Object x){
    if (n >= arr.length)ext(n+1-arr.length);
    arr[n] = x;
    if (n >= len)len = n+1;
    return x;
  }
  
  public int len(){
    return len;
  }
  
  private void ext(int n){
    Object[] arr2 = new Object[arr.length+n];
    
    for (int i = 0; i < len; i++){
      arr2[i] = arr[i];
    }
    for (int i = len; i < arr2.length; i++){
      arr2[i] = null;
    }
    arr = arr2;
  }
  
  public Object rem(int n){
    Object x = arr[n];
    
    for (int i = n+1; i < len; i++){
      arr[i-1] = arr[i];
    }
    arr[len-1] = null;
    len--;
    
    return x;
  }
  
  public Object pop(){
    return rem(len-1);
  }
  
  // popFront/shift
  public Object shf(){
    return rem(0);
  }
  
  public Xarr ins(Object x, int n){
    if (len >= arr.length)ext((len == 0)?1:len);
    for (int i = len-1; i >= n; i--){
      arr[i+1] = arr[i];
    }
    arr[n] = x;
    len++;
    return this;
  }
  
  public Xarr push(Object x){
    return ins(x, len);
  }
  
  // pushFront/unshift
  public Xarr ushf(Object x){
    return ins(x, 0);
  }
  
  public String toString(){
    String str = "[";
    if (len > 0){
      str += arr[0].toString();
      for (int i = 1; i < len; i++){
        str += ", " + arr[i].toString();
      }
    }
    str += "]";
    return str;
  }
  
  public Object[] arr(){
    Object[] arr2 = (Object[]) Array.newInstance(Object.class, len);
    
    for (int i = 0; i < len; i++){
      arr2[i] = arr[i];
    }
    
    return arr2;
  }
}